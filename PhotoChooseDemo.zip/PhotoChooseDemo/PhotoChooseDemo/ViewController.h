//
//  ViewController.h
//  PhotoChooseDemo
//
//  Created by 张一雄 on 16/4/18.
//  Copyright © 2016年 HuaXiong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

